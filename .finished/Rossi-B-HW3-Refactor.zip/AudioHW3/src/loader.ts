import * as main from "./main";

window.onload = () => {
    main.init();
};